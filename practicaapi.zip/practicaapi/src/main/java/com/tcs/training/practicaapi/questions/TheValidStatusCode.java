package com.tcs.training.practicaapi.questions;

import com.tcs.training.practicaapi.models.UserInformation;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.util.List;

public class TheValidStatusCode implements Question<Integer> {
    @Override
    public Integer answeredBy(Actor actor) {

        return SerenityRest.lastResponse().statusCode();
    }
    public static TheValidStatusCode ofApi(){
        return new TheValidStatusCode();
    }
}
