package com.tcs.training.practicaapi.questions;

import com.tcs.training.practicaapi.models.UserInformation;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class TheValidInformacion implements Question<Boolean> {

    private UserInformation userInformation;

    public TheValidInformacion(UserInformation userInformation) {
        this.userInformation = userInformation;
    }

    @Override
    public Boolean answeredBy(Actor actor) {
        SerenityRest.lastResponse().jsonPath().getList("",UserInformation.class);
        return null;
    }

    public static TheValidInformacion ofApi(UserInformation userInformation){
        return new TheValidInformacion(userInformation);
    }
}
