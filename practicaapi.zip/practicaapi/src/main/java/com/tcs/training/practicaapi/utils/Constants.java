package com.tcs.training.practicaapi.utils;

public class Constants {

    public static final String BASE_API_ENDPOINT = "https://jsonplaceholder.typicode.com";
    public static final String USERS_API_ENDPOINT = "/users";
}
