package com.tcs.training.practicaapi.stepdefinitions;

import com.tcs.training.practicaapi.models.UserInformation;
import com.tcs.training.practicaapi.questions.TheValidInformacion;
import com.tcs.training.practicaapi.questions.TheValidStatusCode;
import com.tcs.training.practicaapi.tasks.ConsumeInformation;
import com.tcs.training.practicaapi.utils.Constants;
import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.GivenWhenThen;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import org.hamcrest.Matchers;

import java.util.List;

import static com.tcs.training.practicaapi.utils.Constants.BASE_API_ENDPOINT;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class ApiRestStepDefinitions {

    @Before
    public void setUp(){
        OnStage.setTheStage(new OnlineCast());
    }


    @When("^the user consults the information$")
    public void theUserConsultsTheInformation() {
        OnStage.theActorCalled("Sebatian").whoCan(CallAnApi.at(BASE_API_ENDPOINT));
        theActorInTheSpotlight().attemptsTo(ConsumeInformation.api());
    }


    @Then("^the user will see the response (\\d+)$")
    public void theUserWillSeeTheResponse(int status) {
        theActorInTheSpotlight().should(seeThat(TheValidStatusCode.ofApi(), Matchers.equalTo(status)));
    }

    @Then("^the user should validate information$")
    public void theUserShouldValidateInformation(List<UserInformation> userInformationList) {
        OnStage.theActorInTheSpotlight().should(seeThat(TheValidInformacion.ofApi(userInformationList.get(0))));
    }

}
