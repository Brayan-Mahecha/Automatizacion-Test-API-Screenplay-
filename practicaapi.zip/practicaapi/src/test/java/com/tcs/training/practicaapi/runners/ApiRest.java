package com.tcs.training.practicaapi.runners;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features = "src\\test\\resources\\features\\api_rest.feature",
        glue = "com.tcs.training.practicaapi.stepdefinitions",
        snippets = SnippetType.CAMELCASE
        , tags = "@scenario2"
)
public class ApiRest {
}
